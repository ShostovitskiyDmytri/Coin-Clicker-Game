# Coin Clicker

[zombie-unicorn.pl - Coin Clicker](http://zombie-unicorn.pl/projects-java-coin-clicker/)

Created using Android Studio

Coin Clicker is a simple Android App.  
The main objective is clicking gold coin or shaking phone to get more coins.  
The more $ you have the better upgrades you can buy from the shop.

[![YT link](https://img.youtube.com/vi/0Fq4y48u5Gc/maxresdefault.jpg)](https://www.youtube.com/watch?v=0Fq4y48u5Gc)

Images come from:
* [Coin image](https://opengameart.org/content/coin-icon)
* [Others](https://www.iconspng.com/)
